# community/serializers.py

from rest_framework import serializers
from .models import ClubPost, LostItem, Comment

# 1. 동아리 게시물 Serializer
class ClubPostSerializer(serializers.ModelSerializer):
    author_username = serializers.ReadOnlyField(source='author.username') 

    class Meta:
        model = ClubPost
        fields = ('id', 'author', 'author_username', 'category', 'title', 'content', 'created_at')
        read_only_fields = ('author',) 

# 2. 분실물 게시물 Serializer
class LostItemSerializer(serializers.ModelSerializer):
    finder_username = serializers.ReadOnlyField(source='finder.username') 

    class Meta:
        model = LostItem
        fields = ('id', 'finder', 'finder_username', 'title', 'description', 'location', 'finder_contact', 'status', 'created_at')
        read_only_fields = ('finder',)
        
# 3. 댓글 Serializer
class CommentSerializer(serializers.ModelSerializer):
    author_username = serializers.ReadOnlyField(source='author.username')
    
    class Meta:
        model = Comment
        fields = ('id', 'author', 'author_username', 'content', 'created_at', 'club_post', 'lost_item')
        read_only_fields = ('author', 'club_post', 'lost_item')