# community/models.py (전체 내용)
from django.db import models
from django.contrib.auth.models import User

# 1. 동아리 게시물 모델
class ClubPost(models.Model):
    POST_CHOICES = (
        ('PROMO', '홍보/모집'),
        ('NOTICE', '공지사항'),
    )
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='club_posts', verbose_name="작성자")
    category = models.CharField(max_length=10, choices=POST_CHOICES, default='PROMO', verbose_name="카테고리")
    title = models.CharField(max_length=150, verbose_name="제목")
    content = models.TextField(verbose_name="내용")
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f'[{self.get_category_display()}] {self.title}'

# 2. 분실물 게시물 모델
class LostItem(models.Model):
    STATUS_CHOICES = (
        ('FOUND', '습득'),
        ('RETURNED', '반환 완료'),
    )
    finder = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='found_items', verbose_name="습득자")
    title = models.CharField(max_length=150, verbose_name="물품 이름")
    description = models.TextField(verbose_name="상세 설명")
    location = models.CharField(max_length=100, verbose_name="습득 장소")
    finder_contact = models.CharField(max_length=100, verbose_name="습득자 연락처") 
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='FOUND', verbose_name="처리 상태")
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f'[{self.get_status_display()}] {self.title}'

# 3. 댓글 모델 (이전에 논의했던 내용 포함)
class Comment(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="댓글 작성자")
    club_post = models.ForeignKey(
        ClubPost, on_delete=models.CASCADE, related_name='comments', 
        null=True, blank=True, verbose_name="동아리 게시물"
    )
    lost_item = models.ForeignKey(
        LostItem, on_delete=models.CASCADE, related_name='comments', 
        null=True, blank=True, verbose_name="분실물 게시물"
    )
    content = models.TextField(verbose_name="댓글 내용")
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f'Comment by {self.author.username}'

# (시간표 모델은 사용자님 요청에 따라 제외합니다.)