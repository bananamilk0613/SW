# community/views.py

from rest_framework import viewsets, permissions, status
from rest_framework.response import Response
from .models import ClubPost, LostItem, Comment
from .serializers import ClubPostSerializer, LostItemSerializer, CommentSerializer

# 1. 동아리 게시판 ViewSet
class ClubPostViewSet(viewsets.ModelViewSet):
    # 최신순 정렬
    queryset = ClubPost.objects.all().order_by('-created_at') 
    serializer_class = ClubPostSerializer
    permission_classes = [permissions.IsAuthenticated] # 로그인 필수

    # 게시물 저장 시, 작성자를 현재 로그인 사용자로 자동 지정
    def perform_create(self, serializer):
        serializer.save(author=self.request.user)
        
# 2. 분실물 게시판 ViewSet
class LostItemViewSet(viewsets.ModelViewSet):
    # 'FOUND' 상태의 물품만 기본으로 보여주고 최신순 정렬
    queryset = LostItem.objects.filter(status='FOUND').order_by('-created_at') 
    serializer_class = LostItemSerializer
    permission_classes = [permissions.IsAuthenticated]

    # 게시물 저장 시, 습득자를 현재 로그인 사용자로 자동 지정
    def perform_create(self, serializer):
        serializer.save(finder=self.request.user)
        
# 3. 댓글 ViewSet
class CommentViewSet(viewsets.ModelViewSet):
    serializer_class = CommentSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        # URL에서 게시물 ID(post_pk 또는 lostitem_pk)를 가져와 필터링합니다.
        post_pk = self.kwargs.get('post_pk')
        lostitem_pk = self.kwargs.get('lostitem_pk')
        
        if post_pk:
            return Comment.objects.filter(club_post_id=post_pk).order_by('created_at')
        elif lostitem_pk:
            return Comment.objects.filter(lost_item_id=lostitem_pk).order_by('created_at')
        
        return Comment.objects.none() # ID가 없으면 댓글 반환하지 않음

    def perform_create(self, serializer):
        # 댓글 저장 시, URL의 PK에 따라 게시물 객체를 연결합니다.
        post_pk = self.kwargs.get('post_pk')
        lostitem_pk = self.kwargs.get('lostitem_pk')
        
        if post_pk:
            post = ClubPost.objects.get(pk=post_pk)
            serializer.save(author=self.request.user, club_post=post)
        elif lostitem_pk:
            item = LostItem.objects.get(pk=lostitem_pk)
            serializer.save(author=self.request.user, lost_item=item)
        else:
            raise status.HTTP_400_BAD_REQUEST("댓글을 달 게시물 ID를 찾을 수 없습니다.")