# community/urls.py (최종 형태)
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ClubPostViewSet, LostItemViewSet, CommentViewSet

# 1. 메인 게시판 라우터 (ClubPost, LostItem)
router = DefaultRouter()
router.register(r'clubposts', ClubPostViewSet) 
router.register(r'lostitems', LostItemViewSet)

# 2. 댓글 URL 수동 연결 (게시물 ID를 포함하는 계층적 구조)
urlpatterns = [
    # ClubPost 댓글 URL (댓글 목록 조회 및 생성)
    path('clubposts/<int:post_pk>/comments/', 
         CommentViewSet.as_view({'get': 'list', 'post': 'create'}), name='clubpost-comment-list'),
    # ClubPost 댓글 상세 URL (수정, 삭제)
    path('clubposts/<int:post_pk>/comments/<int:pk>/', 
         CommentViewSet.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}), name='clubpost-comment-detail'),

    # LostItem 댓글 URL (댓글 목록 조회 및 생성)
    path('lostitems/<int:lostitem_pk>/comments/', 
         CommentViewSet.as_view({'get': 'list', 'post': 'create'}), name='lostitem-comment-list'),
    # LostItem 댓글 상세 URL (수정, 삭제)
    path('lostitems/<int:lostitem_pk>/comments/<int:pk>/', 
         CommentViewSet.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}), name='lostitem-comment-detail'),
]

# 3. 라우터의 URL을 최종 리스트에 추가
urlpatterns += router.urls