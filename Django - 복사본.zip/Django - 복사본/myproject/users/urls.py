# users/urls.py

from django.urls import path
from .views import RegisterView, LoginView

urlpatterns = [
    # POST 요청: /auth/register/ -> 회원가입 처리
    path('register/', RegisterView.as_view(), name='register'), 
    # POST 요청: /auth/login/ -> 로그인 및 토큰 발급 처리
    path('login/', LoginView.as_view(), name='login'), 
]