from django.shortcuts import render

# Create your views here.

# users/views.py

from rest_framework import generics, permissions
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from django.contrib.auth.models import User

from .serializers import UserRegistrationSerializer

# 1. 회원가입 (Registration) View
class RegisterView(generics.CreateAPIView):
    # 누구나 접근 가능해야 합니다.
    permission_classes = (permissions.AllowAny,) 
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer

# 2. 로그인 (Login) View
# Django REST Framework의 기본 ObtainAuthToken을 상속받아 사용합니다.
class LoginView(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        # ObtainAuthToken의 기본 로직을 사용하여 사용자 인증 및 토큰 검색/생성
        serializer = self.serializer_class(data=request.data,
                                           context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        
        # Kivy 앱에 토큰과 사용자 ID를 반환하여 로그인 상태를 유지하도록 합니다.
        return Response({
            'token': token.key,
            'user_id': user.pk,
            'username': user.username
        })