# users/serializers.py

from rest_framework import serializers
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token # 토큰 발급에 필요

# 1. 회원가입 (User Creation) Serializer
class UserRegistrationSerializer(serializers.ModelSerializer):
    # 비밀번호는 쓰기 전용으로 설정하여 응답 시 노출되지 않게 합니다.
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'password')
        # 'email'은 선택 사항이지만, 향후 필요할 수 있으므로 포함합니다.

    # save()가 호출될 때 실제 사용자 생성 로직을 처리합니다.
    def create(self, validated_data):
        # 비밀번호를 해시 처리하여 보안을 강화합니다.
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=validated_data['password']
        )
        # 사용자 생성 직후 인증 토큰을 생성하여 할당합니다.
        Token.objects.create(user=user)
        return user